// FuzzyLogicDSL.scala

object FuzzyLogicDSL {
  // Define a FuzzySet as a Map from String (element name) to Double (membership value)
  type FuzzySet = Map[String, Double]

  // Sealed trait for all fuzzy expressions
  sealed trait FuzzyExpr

  // Case classes for different types of fuzzy expressions
  case class Input(name: String, value: Double) extends FuzzyExpr
  case class Union(left: FuzzyExpr, right: FuzzyExpr) extends FuzzyExpr
  case class Intersection(left: FuzzyExpr, right: FuzzyExpr) extends FuzzyExpr
  case class Complement(expr: FuzzyExpr) extends FuzzyExpr
  case class Add(left: FuzzyExpr, right: FuzzyExpr) extends FuzzyExpr
  case class Multiply(left: FuzzyExpr, right: FuzzyExpr) extends FuzzyExpr
  case class XOR(left: FuzzyExpr, right: FuzzyExpr) extends FuzzyExpr
  case class AlphaCut(set: FuzzyExpr, alpha: Double) extends FuzzyExpr
  case class Scope(name: String, expr: FuzzyExpr) extends FuzzyExpr
  case class Assign(name: String, expr: FuzzyExpr) extends FuzzyExpr
  case class TestGate(name: String, input: (String, Double)) extends FuzzyExpr
  case class FuzzySetExpr(set: FuzzySet) extends FuzzyExpr

  // Case classes for OOP features
  case class ClassDef(name: String, superClass: Option[String], vars: List[ClassVar], methods: List[Method]) extends FuzzyExpr
  case class ClassVar(name: String, varType: String)
  case class Method(name: String, params: List[Parameter], body: FuzzyExpr)
  case class Parameter(name: String, paramType: String)
  case class CreateNew(className: String) extends FuzzyExpr
  case class InvokeMethod(instance: FuzzyExpr, methodName: String, args: List[FuzzyExpr]) extends FuzzyExpr

  class FuzzyLogicInterpreter {
    // Environment to store variables and their values
    private var environment: Map[String, Any] = Map.empty
    // Store class definitions
    private var classDefinitions: Map[String, ClassDef] = Map.empty
    // Counter for creating unique instance names
    private var instanceCounter: Int = 0

    // Helper method to extract FuzzySet from FuzzyExpr
    private def extractFuzzySet(expr: FuzzyExpr): FuzzySet = expr match {
      case FuzzySetExpr(set) => set
      case _ => interpret(expr).asInstanceOf[FuzzySet]
    }

    // Helper method to get all methods of a class, including inherited ones
    private def getAllMethods(className: String): List[Method] = {
      classDefinitions.get(className) match {
        case Some(classDef) =>
          val inheritedMethods = classDef.superClass.map(getAllMethods).getOrElse(List.empty)
          classDef.methods ++ inheritedMethods
        case None => List.empty
      }
    }

    // Main interpret method to evaluate FuzzyExpr
    def interpret(expr: FuzzyExpr): Any = expr match {
      case Input(name, value) => Map(name -> value)

      case Union(left, right) =>
        val leftSet = extractFuzzySet(left)
        val rightSet = extractFuzzySet(right)
        (leftSet.keySet ++ rightSet.keySet).map { key =>
          key -> math.max(leftSet.getOrElse(key, 0.0), rightSet.getOrElse(key, 0.0))
        }.toMap

      case Intersection(left, right) =>
        val leftSet = extractFuzzySet(left)
        val rightSet = extractFuzzySet(right)
        (leftSet.keySet ++ rightSet.keySet).map { key =>
          key -> math.min(leftSet.getOrElse(key, 1.0), rightSet.getOrElse(key, 1.0))
        }.toMap

      case Complement(expr) =>
        extractFuzzySet(expr).map { case (key, value) => key -> (1.0 - value) }

      case Add(left, right) =>
        val leftSet = extractFuzzySet(left)
        val rightSet = extractFuzzySet(right)
        (leftSet.keySet ++ rightSet.keySet).map { key =>
          key -> math.min(1.0, leftSet.getOrElse(key, 0.0) + rightSet.getOrElse(key, 0.0))
        }.toMap

      case Multiply(left, right) =>
        val leftSet = extractFuzzySet(left)
        val rightSet = extractFuzzySet(right)
        (leftSet.keySet ++ rightSet.keySet).map { key =>
          key -> (leftSet.getOrElse(key, 0.0) * rightSet.getOrElse(key, 0.0))
        }.toMap

      case XOR(left, right) =>
        val leftSet = extractFuzzySet(left)
        val rightSet = extractFuzzySet(right)
        (leftSet.keySet ++ rightSet.keySet).map { key =>
          val leftVal = leftSet.getOrElse(key, 0.0)
          val rightVal = rightSet.getOrElse(key, 0.0)
          key -> math.abs(leftVal - rightVal)
        }.toMap

      case AlphaCut(set, alpha) =>
        extractFuzzySet(set).filter(_._2 >= alpha)

      case Scope(name, expr) =>
        val result = interpret(expr)
        environment += (name -> result)
        result

      case Assign(name, expr) =>
        val result = interpret(expr)
        environment += (name -> result)
        result

      case TestGate(name, input) =>
        environment.get(name) match {
          case Some(gate: FuzzySet) => Map(input._1 -> input._2)
          case None => throw new RuntimeException(s"Undefined gate: $name")
        }

      case FuzzySetExpr(set) => set

      case ClassDef(name, superClass, vars, methods) =>
        val inheritedVars = superClass.flatMap(classDefinitions.get).map(_.vars).getOrElse(List.empty)
        val allVars = inheritedVars ++ vars
        classDefinitions += (name -> ClassDef(name, superClass, allVars, methods))
        name

      case CreateNew(className) =>
        classDefinitions.get(className) match {
          case Some(classDef) =>
            val instanceName = s"${className}_instance_$instanceCounter"
            instanceCounter += 1
            val instance = ClassInstance(instanceName, className, Map.empty)
            environment += (instanceName -> instance)
            Map(instanceName -> 1.0)
          case None => throw new RuntimeException(s"Undefined class: $className")
        }

      case InvokeMethod(instance, methodName, args) =>
        val instanceSet = extractFuzzySet(instance)
        val instanceName = instanceSet.keys.headOption.getOrElse(throw new RuntimeException("Invalid instance expression"))
        environment.get(instanceName) match {
          case Some(classInstance: ClassInstance) =>
            val allMethods = getAllMethods(classInstance.className)
            allMethods.find(_.name == methodName) match {
              case Some(method) =>
                val methodEnv = method.params.zip(args).map { case (param, arg) =>
                  param.name -> interpret(arg)
                }.toMap
                val oldEnv = environment
                environment = environment ++ methodEnv
                val result = interpret(method.body)
                environment = oldEnv
                result
              case None => throw new RuntimeException(s"Undefined method: $methodName")
            }
          case _ => throw new RuntimeException(s"Invalid instance: $instanceName")
        }
    }
  }

  // Case class to represent class instances
  case class ClassInstance(name: String, className: String, variables: Map[String, Any])
}
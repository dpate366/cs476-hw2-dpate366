import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers
import FuzzyLogicDSL._

class FuzzyLogicDSLTest extends AnyFlatSpec with Matchers {
  // Helper method to create a new interpreter for each test
  def newInterpreter() = new FuzzyLogicInterpreter()

  // Custom equality checker for FuzzySets to handle floating-point precision
  def fuzzySetEquals(actual: FuzzySet, expected: FuzzySet, epsilon: Double = 1e-6): Boolean = {
    actual.keySet == expected.keySet &&
      actual.forall { case (key, value) =>
        math.abs(value - expected(key)) < epsilon
      }
  }

  // Helper method to assert equality of FuzzySets
  def assertFuzzySetEquals(actual: FuzzySet, expected: FuzzySet): Unit = {
    withClue(s"Actual: $actual\nExpected: $expected\n") {
      fuzzySetEquals(actual, expected) shouldBe true
    }
  }

  // Test 1: Create and evaluate simple inputs
  "FuzzyLogicDSL" should "create and evaluate simple inputs" in {
    val interpreter = newInterpreter()
    val input = Input("A", 0.7)
    assertFuzzySetEquals(interpreter.interpret(input).asInstanceOf[FuzzySet], Map("A" -> 0.7))
  }

  // Test 2: Perform union operation
  it should "perform union operation" in {
    val interpreter = newInterpreter()
    val union = Union(Input("A", 0.7), Input("B", 0.5))
    assertFuzzySetEquals(interpreter.interpret(union).asInstanceOf[FuzzySet], Map("A" -> 0.7, "B" -> 0.5))
  }

  // Test 3: Perform intersection operation
  it should "perform intersection operation" in {
    val interpreter = newInterpreter()
    val intersection = Intersection(Input("A", 0.7), Input("B", 0.5))
    assertFuzzySetEquals(interpreter.interpret(intersection).asInstanceOf[FuzzySet], Map("A" -> 0.7, "B" -> 0.5))
  }

  // Test 4: Calculate complement
  it should "calculate complement" in {
    val interpreter = newInterpreter()
    val complement = Complement(Input("A", 0.7))
    assertFuzzySetEquals(interpreter.interpret(complement).asInstanceOf[FuzzySet], Map("A" -> 0.3))
  }

  // Test 5: Perform alpha-cut
  it should "perform alpha-cut" in {
    val interpreter = newInterpreter()
    val alphaCut = AlphaCut(FuzzySetExpr(Map("A" -> 0.7, "B" -> 0.3, "C" -> 0.5)), 0.5)
    assertFuzzySetEquals(interpreter.interpret(alphaCut).asInstanceOf[FuzzySet], Map("A" -> 0.7, "C" -> 0.5))
  }

  // Test 6: Handle scopes
  it should "handle scopes" in {
    val interpreter = newInterpreter()
    val scopedExpr = Scope("local", Assign("X", Input("A", 0.7)))
    assertFuzzySetEquals(interpreter.interpret(scopedExpr).asInstanceOf[FuzzySet], Map("A" -> 0.7))
  }

  // Test 7: Perform assignments
  it should "perform assignments" in {
    val interpreter = newInterpreter()
    val assignment = Assign("Y", Input("B", 0.6))
    assertFuzzySetEquals(interpreter.interpret(assignment).asInstanceOf[FuzzySet], Map("B" -> 0.6))
  }

  // Test 8: Define a simple class
  it should "define a simple class" in {
    val interpreter = newInterpreter()
    val classDef = ClassDef("SimpleClass", None, List(ClassVar("x", "Double")), List(Method("getX", List(), Input("x", 0.5))))
    interpreter.interpret(classDef) shouldBe "SimpleClass"
  }

  // Test 9: Create an instance of a class
  it should "create an instance of a class" in {
    val interpreter = newInterpreter()
    interpreter.interpret(ClassDef("SimpleClass", None, List(ClassVar("x", "Double")), List(Method("getX", List(), Input("x", 0.5)))))
    val instanceSet = interpreter.interpret(CreateNew("SimpleClass")).asInstanceOf[FuzzySet]
    instanceSet.keys.head should startWith("SimpleClass_instance_")
  }

  // Test 10: Invoke a method on a class instance
  it should "invoke a method on a class instance" in {
    val interpreter = newInterpreter()
    interpreter.interpret(ClassDef("SimpleClass", None, List(ClassVar("x", "Double")), List(Method("getX", List(), Input("x", 0.5)))))
    val instanceSet = interpreter.interpret(CreateNew("SimpleClass")).asInstanceOf[FuzzySet]
    val result = interpreter.interpret(InvokeMethod(FuzzySetExpr(instanceSet), "getX", List())).asInstanceOf[FuzzySet]
    assertFuzzySetEquals(result, Map("x" -> 0.5))
  }

  // Test 11: Define a class with inheritance
  it should "define a class with inheritance" in {
    val interpreter = newInterpreter()
    interpreter.interpret(ClassDef("BaseClass", None, List(ClassVar("x", "Double")), List(Method("getX", List(), Input("x", 0.5)))))
    val derivedClass = ClassDef("DerivedClass", Some("BaseClass"), List(ClassVar("y", "Double")), List(Method("getY", List(), Input("y", 0.7))))
    interpreter.interpret(derivedClass) shouldBe "DerivedClass"
  }

  // Test 12: Invoke a method from a superclass
  it should "invoke a method from a superclass" in {
    val interpreter = newInterpreter()
    interpreter.interpret(ClassDef("BaseClass", None, List(ClassVar("x", "Double")), List(Method("getX", List(), Input("x", 0.5)))))
    interpreter.interpret(ClassDef("DerivedClass", Some("BaseClass"), List(ClassVar("y", "Double")), List(Method("getY", List(), Input("y", 0.7)))))
    val instanceSet = interpreter.interpret(CreateNew("DerivedClass")).asInstanceOf[FuzzySet]
    val result = interpreter.interpret(InvokeMethod(FuzzySetExpr(instanceSet), "getX", List())).asInstanceOf[FuzzySet]
    assertFuzzySetEquals(result, Map("x" -> 0.5))
  }
  // Additional test to verify both inherited and own methods
  it should "invoke both inherited and own methods" in {
    val interpreter = newInterpreter()
    interpreter.interpret(ClassDef("BaseClass", None, List(ClassVar("x", "Double")), List(Method("getX", List(), Input("x", 0.5)))))
    interpreter.interpret(ClassDef("DerivedClass", Some("BaseClass"), List(ClassVar("y", "Double")), List(Method("getY", List(), Input("y", 0.7)))))
    val instanceSet = interpreter.interpret(CreateNew("DerivedClass")).asInstanceOf[FuzzySet]

    val resultX = interpreter.interpret(InvokeMethod(FuzzySetExpr(instanceSet), "getX", List())).asInstanceOf[FuzzySet]
    assertFuzzySetEquals(resultX, Map("x" -> 0.5))

    val resultY = interpreter.interpret(InvokeMethod(FuzzySetExpr(instanceSet), "getY", List())).asInstanceOf[FuzzySet]
    assertFuzzySetEquals(resultY, Map("y" -> 0.7))
  }
}